"""Niulai local cloud brain."""
